const token = window.__ALEX_DASHBOARD_TOKEN__;
const form = document.querySelector('#pair-form');
const pairingCode = document.querySelector('#pairing-code');
const startButton = document.querySelector('#start');
const stopButton = document.querySelector('#stop');
const statusBox = document.querySelector('#status');
const statusTitle = statusBox.querySelector('strong');
const statusDetails = statusBox.querySelector('small');
let shuttingDown = false;

function phaseText(status) {
  if (status.sessionActive) return 'Удалённый браузер работает';
  if (status.accountPaired) return 'Mac привязан к аккаунту';
  if (status.agentConnected) return 'Mac ожидает привязки';
  if (status.phase === 'starting') return 'Подключаю Mac…';
  if (status.phase === 'error') return 'Ошибка подключения';
  return 'Mac-сервер запускается';
}

function renderStatus(status) {
  statusBox.dataset.phase = status.phase;
  pairingCode.textContent = status.accountPaired ? 'ПРИВЯЗАН' : (status.pairingCode || '••••••••');
  statusTitle.textContent = phaseText(status);
  const parts = [];
  if (status.message && status.message !== phaseText(status)) parts.push(status.message);
  if (status.sessionActive) {
    parts.push(`${Number(status.frameRate || 0).toFixed(0)} кадр/с`);
    parts.push(`передано: ${Number(status.framesSent || 0)}`);
    parts.push(`учеников через резерв: ${Number(status.relayViewers || 0)}`);
  }
  if (status.relayPhase === 'ready') parts.push('резервный канал готов');
  else if (status.relayMessage) parts.push(status.relayMessage);
  statusDetails.textContent = parts.join(' · ');
  stopButton.disabled = !status.agentConnected && status.phase !== 'starting' && status.phase !== 'error';
  startButton.disabled = status.phase === 'starting';
}

async function request(path, options = {}) {
  const response = await fetch(path, {
    ...options,
    headers: {
      'content-type': 'application/json',
      'x-alex-dashboard-token': token,
      ...(options.headers || {}),
    },
  });
  const payload = await response.json();
  if (!response.ok) throw new Error(payload.error || 'Локальный сервер отклонил запрос');
  return payload;
}

async function refresh() {
  if (shuttingDown) return;
  try {
    const response = await fetch('/api/status', { cache: 'no-store' });
    renderStatus(await response.json());
  } catch {
    statusTitle.textContent = 'Локальный сервер недоступен';
    statusDetails.textContent = 'Закройте это окно и снова запустите команду запуска.';
    statusBox.dataset.phase = 'error';
  }
}

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  startButton.disabled = true;
  statusTitle.textContent = 'Запускаю Chrome…';
  statusDetails.textContent = 'Первая загрузка может занять несколько секунд.';
  try {
    renderStatus(await request('/api/start', {
      method: 'POST',
      body: '{}',
    }));
  } catch (error) {
    renderStatus({ phase: 'error', message: error.message });
  } finally {
    startButton.disabled = false;
  }
});

stopButton.addEventListener('click', async () => {
  if (!window.confirm('Отключить фоновый сервер? Его можно снова запустить файлом «Запустить Alex Browser».')) return;
  stopButton.disabled = true;
  try {
    await request('/api/shutdown', { method: 'POST', body: '{}' });
    shuttingDown = true;
    statusBox.dataset.phase = 'idle';
    statusTitle.textContent = 'Сервер отключён';
    statusDetails.textContent = 'Закройте это окно. Для нового запуска откройте файл «Запустить Alex Browser».';
    startButton.disabled = true;
  } catch (error) {
    renderStatus({ phase: 'error', message: error.message });
    stopButton.disabled = false;
  }
});

refresh();
setInterval(refresh, 1_000);
