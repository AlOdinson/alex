import { timingSafeEqual } from 'node:crypto';

function safeEqual(leftValue, rightValue) {
  const left = Buffer.from(String(leftValue ?? ''));
  const right = Buffer.from(String(rightValue ?? ''));
  if (!left.length || left.length !== right.length) return false;
  return timingSafeEqual(left, right);
}

export function relayRequestIsAllowed({
  origin,
  boardOrigin,
  sessionId,
  expectedSessionId,
  token,
  expectedToken,
  viewerId,
}) {
  const normalizedViewerId = String(viewerId ?? '');
  return Boolean(boardOrigin)
    && String(origin ?? '') === String(boardOrigin)
    && safeEqual(sessionId, expectedSessionId)
    && safeEqual(token, expectedToken)
    && normalizedViewerId.length >= 6
    && normalizedViewerId.length <= 120
    && /^[A-Za-z0-9_-]+$/.test(normalizedViewerId);
}
