import { createHash, randomBytes } from 'node:crypto';
import { createReadStream } from 'node:fs';
import { access, chmod, mkdir, readFile, writeFile } from 'node:fs/promises';
import { createServer } from 'node:http';
import { homedir, hostname } from 'node:os';
import { dirname, extname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawn } from 'node:child_process';
import { chromium } from 'playwright-core';
import { WebSocket, WebSocketServer } from 'ws';
import {
  normalizedNavigationUrl,
  remoteRequestIsAllowed,
} from './urlSafety.mjs';
import { relayRequestIsAllowed } from './relaySecurity.mjs';

const SOURCE_DIR = dirname(fileURLToPath(import.meta.url));
const PROJECT_DIR = dirname(SOURCE_DIR);
const PUBLIC_DIR = join(PROJECT_DIR, 'public');
const PORT = Number(process.env.ALEX_BROWSER_PORT || 4318);
const HOST = '127.0.0.1';
const VIEWPORT = Object.freeze({ width: 1920, height: 1080 });
const DASHBOARD_TOKEN = randomBytes(24).toString('base64url');
const FRAME_QUALITY = 68;
const MAX_BRIDGE_BUFFER = 2_400_000;
const MAX_RELAY_VIEWERS = 4;
const MAX_RELAY_BUFFER = 3_200_000;
const SERVER_VERSION = '1.35.0';
const BOARD_APP_URL = String(process.env.ALEX_BOARD_APP_URL || 'https://alodinson.github.io/alex/');
const AGENT_STATE_DIR = join(homedir(), 'Library', 'Application Support', 'Alex Board');
const AGENT_STATE_FILE = join(AGENT_STATE_DIR, 'mac-agent.json');
const BACKGROUND_SERVICE = process.env.ALEX_BROWSER_BACKGROUND === '1';
const DEVICE_NAME = String(process.env.ALEX_BROWSER_DEVICE_NAME || hostname().split('.')[0] || 'Mac').slice(0, 80);

const CHROME_PATHS = [
  '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
  '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge',
  '/Applications/Chromium.app/Contents/MacOS/Chromium',
];

const CLOUDFLARED_PATHS = [
  process.env.ALEX_CLOUDFLARED_PATH,
  '/opt/homebrew/bin/cloudflared',
  '/usr/local/bin/cloudflared',
].filter(Boolean);

const runtime = {
  serverVersion: SERVER_VERSION,
  backgroundService: BACKGROUND_SERVICE,
  phase: 'idle',
  message: 'Mac-сервер готов',
  boardUrl: '',
  pairingCode: '',
  accountPaired: false,
  agentConnected: false,
  signalTransport: '',
  sessionActive: false,
  currentUrl: '',
  title: '',
  frameRate: 0,
  quality: FRAME_QUALITY,
  framesSent: 0,
  framesDropped: 0,
  relayPhase: 'starting',
  relayMessage: 'Запускаю защищённый резервный канал…',
  relayUrl: '',
  relayViewers: 0,
  relayFramesSent: 0,
  relayFramesDropped: 0,
  startedAt: null,
};

let browser = null;
let agentContext = null;
let agentPage = null;
let bridge = null;
let bridgeToken = '';
let bridgeWaiter = null;
const revokeWaiters = new Map();
let targetContext = null;
let targetPage = null;
let targetCdp = null;
let sessionGeneration = 0;
let historyDepth = 0;
let historyForwardDepth = 0;
let latestFrame = null;
let frameFlushTimer = null;
let lastFrameHash = '';
let lastFrameSentAt = 0;
let lastChangedFrameAt = 0;
let motionUntil = 0;
let activeUntil = 0;
let frameWindowStartedAt = Date.now();
let frameWindowCount = 0;
let activeTouches = new Map();
let stoppingAgent = false;
let boardOrigin = '';
let tunnelProcess = null;
let tunnelStartPromise = null;
let publicRelayBaseUrl = '';
let relaySessionId = '';
let relaySessionToken = '';
let relayState = null;
let lastDeliveredFrame = null;
let agentIdentity = null;
const relayClients = new Map();

function randomPairingCode() {
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const bytes = randomBytes(8);
  return [...bytes].map((value) => alphabet[value % alphabet.length]).join('');
}

async function loadOrCreateAgentIdentity() {
  if (agentIdentity) return agentIdentity;
  try {
    const stored = JSON.parse(await readFile(AGENT_STATE_FILE, 'utf8'));
    if (String(stored.agentToken ?? '').length >= 40 && /^[A-Z0-9]{8}$/.test(String(stored.pairingCode ?? ''))) {
      agentIdentity = {
        agentToken: String(stored.agentToken),
        pairingCode: String(stored.pairingCode),
      };
      return agentIdentity;
    }
  } catch {
    // The first launch creates a new local identity below.
  }
  agentIdentity = {
    agentToken: randomBytes(32).toString('base64url'),
    pairingCode: randomPairingCode(),
  };
  await mkdir(AGENT_STATE_DIR, { recursive: true, mode: 0o700 });
  await writeFile(AGENT_STATE_FILE, JSON.stringify(agentIdentity, null, 2), { mode: 0o600 });
  await chmod(AGENT_STATE_FILE, 0o600).catch(() => undefined);
  return agentIdentity;
}

function updateRuntime(patch) {
  Object.assign(runtime, patch);
}

function jsonResponse(response, statusCode, payload) {
  const body = JSON.stringify(payload);
  response.writeHead(statusCode, {
    'content-type': 'application/json; charset=utf-8',
    'content-length': Buffer.byteLength(body),
    'cache-control': 'no-store',
    'x-content-type-options': 'nosniff',
  });
  response.end(body);
}

function dashboardRequestAuthorized(request) {
  const origin = String(request.headers.origin || '');
  const localOrigin = origin === `http://${HOST}:${PORT}` || origin === `http://localhost:${PORT}`;
  return localOrigin && request.headers['x-alex-dashboard-token'] === DASHBOARD_TOKEN;
}

async function readJsonBody(request, limit = 32_000) {
  const chunks = [];
  let length = 0;
  for await (const chunk of request) {
    length += chunk.length;
    if (length > limit) throw new Error('Запрос слишком большой');
    chunks.push(chunk);
  }
  return JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}');
}

async function findChrome() {
  for (const path of CHROME_PATHS) {
    try {
      // eslint-disable-next-line no-await-in-loop
      await access(path);
      return path;
    } catch {
      // Try the next supported Chromium browser.
    }
  }
  throw new Error('Не найден Google Chrome. Установите Chrome на Mac и повторите запуск.');
}

async function findCloudflared() {
  for (const path of CLOUDFLARED_PATHS) {
    try {
      // eslint-disable-next-line no-await-in-loop
      await access(path);
      return path;
    } catch {
      // Try the next supported installation location.
    }
  }
  return '';
}

function relayWebSocketUrl() {
  if (!publicRelayBaseUrl) return '';
  try {
    const url = new URL(publicRelayBaseUrl);
    url.protocol = url.protocol === 'http:' ? 'ws:' : 'wss:';
    url.pathname = '/relay';
    url.search = '';
    url.hash = '';
    return url.toString();
  } catch {
    return '';
  }
}

function sendRelaySessionInfo() {
  const url = relayWebSocketUrl();
  if (!url || !relaySessionId || !relaySessionToken) return false;
  return sendBridgeJson({
    type: 'relay-session',
    relay: {
      url,
      token: relaySessionToken,
      sessionId: relaySessionId,
    },
  });
}

function closeRelayClients(code = 1000, reason = 'session-ended') {
  relayClients.forEach((socket) => {
    try { socket.close(code, reason); } catch { /* Best effort. */ }
  });
  relayClients.clear();
  updateRuntime({ relayViewers: 0 });
}

function beginRelaySession(sessionId) {
  closeRelayClients(1000, 'new-session');
  relaySessionId = String(sessionId || '');
  relaySessionToken = relaySessionId ? randomBytes(32).toString('base64url') : '';
  relayState = null;
  updateRuntime({ relayViewers: 0, relayFramesSent: 0, relayFramesDropped: 0 });
  sendRelaySessionInfo();
}

function endRelaySession() {
  closeRelayClients(1000, 'session-ended');
  relaySessionId = '';
  relaySessionToken = '';
  relayState = null;
  lastDeliveredFrame = null;
}

async function startPublicRelayTunnel() {
  const configuredUrl = String(process.env.ALEX_RELAY_PUBLIC_URL || '').trim();
  if (configuredUrl) {
    publicRelayBaseUrl = configuredUrl;
    updateRuntime({
      relayPhase: 'ready',
      relayMessage: 'Защищённый резервный канал готов',
      relayUrl: relayWebSocketUrl(),
    });
    sendRelaySessionInfo();
    return;
  }

  const executablePath = await findCloudflared();
  if (!executablePath) {
    updateRuntime({
      relayPhase: 'unavailable',
      relayMessage: 'Cloudflared не найден — доступно только прямое P2P-соединение',
      relayUrl: '',
    });
    return;
  }

  updateRuntime({
    relayPhase: 'starting',
    relayMessage: 'Запускаю защищённый резервный канал…',
    relayUrl: '',
  });
  tunnelProcess = spawn(executablePath, [
    'tunnel',
    '--no-autoupdate',
    '--url',
    `http://${HOST}:${PORT}`,
  ], { stdio: ['ignore', 'pipe', 'pipe'] });

  const inspectOutput = (chunk) => {
    const match = String(chunk || '').match(/https:\/\/[a-z0-9-]+\.trycloudflare\.com/i);
    if (!match || publicRelayBaseUrl) return;
    publicRelayBaseUrl = match[0];
    updateRuntime({
      relayPhase: 'ready',
      relayMessage: 'Защищённый резервный канал готов',
      relayUrl: relayWebSocketUrl(),
    });
    sendRelaySessionInfo();
  };
  tunnelProcess.stdout?.on('data', inspectOutput);
  tunnelProcess.stderr?.on('data', inspectOutput);
  tunnelProcess.on('error', (error) => {
    tunnelProcess = null;
    publicRelayBaseUrl = '';
    updateRuntime({
      relayPhase: 'error',
      relayMessage: `Резервный канал не запустился: ${error.message}`,
      relayUrl: '',
    });
  });
  tunnelProcess.on('exit', (code) => {
    tunnelProcess = null;
    publicRelayBaseUrl = '';
    closeRelayClients(1012, 'relay-restarting');
    updateRuntime({
      relayPhase: 'error',
      relayMessage: `Резервный канал остановлен${Number.isInteger(code) ? ` (код ${code})` : ''}`,
      relayUrl: '',
    });
  });
}

async function ensurePublicRelayTunnel() {
  if (publicRelayBaseUrl || tunnelProcess) return;
  if (!tunnelStartPromise) {
    tunnelStartPromise = startPublicRelayTunnel()
      .finally(() => { tunnelStartPromise = null; });
  }
  await tunnelStartPromise;
}

function agentUrlForAccount() {
  const url = new URL(BOARD_APP_URL);
  url.searchParams.set('alexMacAccountHost', '1');
  url.searchParams.set('alexBridgePort', String(PORT));
  url.searchParams.set('alexBridgeToken', bridgeToken);
  return url.toString();
}

async function waitForBridge(timeoutMs = 25_000) {
  if (bridge?.readyState === WebSocket.OPEN) return;
  await new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      bridgeWaiter = null;
      reject(new Error('Служебная вкладка доски не подключилась к Mac-сервису'));
    }, timeoutMs);
    bridgeWaiter = {
      resolve() {
        clearTimeout(timer);
        bridgeWaiter = null;
        resolve();
      },
      reject(error) {
        clearTimeout(timer);
        bridgeWaiter = null;
        reject(error);
      },
    };
  });
}

function safeState() {
  const currentFrameRate = Date.now() - lastFrameSentAt > 1_200 ? 0 : runtime.frameRate;
  return {
    url: targetPage?.url() || '',
    title: runtime.title || '',
    loading: runtime.phase === 'loading',
    canGoBack: historyDepth > 0,
    canGoForward: historyForwardDepth > 0,
    width: VIEWPORT.width,
    height: VIEWPORT.height,
    frameRate: currentFrameRate,
    quality: FRAME_QUALITY,
  };
}

function sendBridgeJson(payload) {
  if (bridge?.readyState !== WebSocket.OPEN) return false;
  try {
    bridge.send(JSON.stringify(payload));
    return true;
  } catch {
    return false;
  }
}

async function requestAgentRevocation(timeoutMs = 8_000) {
  if (bridge?.readyState !== WebSocket.OPEN) {
    throw new Error('Служебный канал Mac не подключён');
  }
  const requestId = randomBytes(18).toString('base64url');
  await new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      revokeWaiters.delete(requestId);
      reject(new Error('Supabase не подтвердил отвязку Mac'));
    }, timeoutMs);
    revokeWaiters.set(requestId, {
      resolve(value) {
        clearTimeout(timer);
        revokeWaiters.delete(requestId);
        resolve(value);
      },
      reject(error) {
        clearTimeout(timer);
        revokeWaiters.delete(requestId);
        reject(error);
      },
    });
    if (!sendBridgeJson({ type: 'agent-revoke-self', requestId })) {
      clearTimeout(timer);
      revokeWaiters.delete(requestId);
      reject(new Error('Не удалось отправить команду отвязки'));
    }
  });
}

function broadcastRelayJson(payload) {
  const body = JSON.stringify(payload);
  relayClients.forEach((socket) => {
    if (socket.readyState !== WebSocket.OPEN) return;
    try { socket.send(body); } catch { /* The close handler removes it. */ }
  });
}

function broadcastRelayFrame(frame) {
  if (!frame || !relayClients.size) return;
  let sent = false;
  let dropped = 0;
  relayClients.forEach((socket) => {
    if (socket.readyState !== WebSocket.OPEN) return;
    if (socket.bufferedAmount > MAX_RELAY_BUFFER) {
      dropped += 1;
      return;
    }
    try {
      socket.send(frame, { binary: true });
      sent = true;
    } catch {
      dropped += 1;
    }
  });
  if (sent || dropped) {
    updateRuntime({
      relayFramesSent: runtime.relayFramesSent + (sent ? 1 : 0),
      relayFramesDropped: runtime.relayFramesDropped + dropped,
    });
  }
}

function sendState() {
  sendBridgeJson({ type: 'state', state: safeState() });
}

async function refreshPageState() {
  if (!targetPage) return;
  let title = '';
  try { title = await targetPage.title(); } catch { /* Page may be navigating. */ }
  updateRuntime({ currentUrl: targetPage.url(), title });
  sendState();
}

function desiredFrameInterval(now) {
  if (now < motionUntil) return 50;
  if (now < activeUntil) return 100;
  return 500;
}

function updateFrameRate(now) {
  frameWindowCount += 1;
  const elapsed = now - frameWindowStartedAt;
  if (elapsed < 1_000) return;
  updateRuntime({ frameRate: (frameWindowCount * 1_000) / Math.max(1, elapsed) });
  frameWindowStartedAt = now;
  frameWindowCount = 0;
  sendState();
}

function flushLatestFrame() {
  frameFlushTimer = null;
  if (!latestFrame || bridge?.readyState !== WebSocket.OPEN) return;
  if (bridge.bufferedAmount > MAX_BRIDGE_BUFFER) {
    updateRuntime({ framesDropped: runtime.framesDropped + 1 });
    frameFlushTimer = setTimeout(flushLatestFrame, 35);
    return;
  }
  const frame = latestFrame;
  latestFrame = null;
  bridge.send(frame, { binary: true });
  lastDeliveredFrame = frame;
  broadcastRelayFrame(frame);
  const now = Date.now();
  lastFrameSentAt = now;
  updateRuntime({ framesSent: runtime.framesSent + 1 });
  updateFrameRate(now);
}

function queueFrame(frame) {
  latestFrame = frame;
  const now = Date.now();
  const wait = Math.max(0, desiredFrameInterval(now) - (now - lastFrameSentAt));
  if (frameFlushTimer) return;
  frameFlushTimer = setTimeout(flushLatestFrame, wait);
}

async function startScreencast(generation) {
  targetCdp = await targetContext.newCDPSession(targetPage);
  targetCdp.on('Page.screencastFrame', (event) => {
    targetCdp?.send('Page.screencastFrameAck', { sessionId: event.sessionId }).catch(() => undefined);
    if (generation !== sessionGeneration || !runtime.sessionActive) return;
    const frame = Buffer.from(event.data, 'base64');
    const hash = createHash('sha1').update(frame).digest('base64url');
    if (hash === lastFrameHash) return;
    lastFrameHash = hash;
    const now = Date.now();
    if (now - lastChangedFrameAt < 260) motionUntil = now + 800;
    lastChangedFrameAt = now;
    queueFrame(frame);
  });
  await targetCdp.send('Page.startScreencast', {
    format: 'jpeg',
    quality: FRAME_QUALITY,
    maxWidth: VIEWPORT.width,
    maxHeight: VIEWPORT.height,
    everyNthFrame: 1,
  });
}

async function createTargetSession(sessionId) {
  if (targetContext) {
    if (relaySessionId === String(sessionId || '')) sendRelaySessionInfo();
    return;
  }
  beginRelaySession(sessionId);
  sessionGeneration += 1;
  const generation = sessionGeneration;
  targetContext = await browser.newContext({
    viewport: VIEWPORT,
    deviceScaleFactor: 1,
    locale: 'ru-RU',
    colorScheme: 'light',
    serviceWorkers: 'block',
  });
  await targetContext.route('**/*', async (route) => {
    if (!remoteRequestIsAllowed(route.request().url())) {
      await route.abort('blockedbyclient');
      return;
    }
    await route.continue();
  });
  targetPage = await targetContext.newPage();
  targetPage.on('domcontentloaded', () => {
    if (generation !== sessionGeneration) return;
    updateRuntime({ phase: 'active' });
    refreshPageState();
  });
  targetPage.on('load', () => {
    if (generation !== sessionGeneration) return;
    updateRuntime({ phase: 'active' });
    refreshPageState();
  });
  targetPage.on('framenavigated', (frame) => {
    if (generation !== sessionGeneration || frame !== targetPage.mainFrame()) return;
    refreshPageState();
  });
  await targetPage.setContent(`<!doctype html><html lang="ru"><head><meta charset="utf-8"><style>
    body{margin:0;min-height:100vh;display:grid;place-items:center;background:#f1f5f9;color:#0f172a;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}
    main{width:min(640px,calc(100% - 48px));padding:42px;border:1px solid #cbd5e1;border-radius:22px;background:#fff;text-align:center;box-shadow:0 20px 60px rgba(15,23,42,.12)}
    h1{margin:0 0 12px;font-size:32px}p{margin:0;color:#475569;font-size:18px;line-height:1.5}
  </style></head><body><main><h1>Alex Browser</h1><p>Введите адрес сайта в строке над окном браузера.</p></main></body></html>`);
  historyDepth = 0;
  historyForwardDepth = 0;
  lastFrameHash = '';
  lastFrameSentAt = 0;
  lastChangedFrameAt = 0;
  motionUntil = Date.now() + 1_000;
  activeUntil = Date.now() + 1_500;
  updateRuntime({
    phase: 'active',
    sessionActive: true,
    currentUrl: '',
    title: 'Alex Browser',
    frameRate: 0,
    framesSent: 0,
    framesDropped: 0,
  });
  await startScreencast(generation);
  await refreshPageState();
}

async function closeTargetSession(reason = 'stopped') {
  sessionGeneration += 1;
  clearTimeout(frameFlushTimer);
  frameFlushTimer = null;
  latestFrame = null;
  activeTouches = new Map();
  try { await targetCdp?.send('Page.stopScreencast'); } catch { /* Target may already be closed. */ }
  targetCdp = null;
  try { await targetContext?.close(); } catch { /* Best effort cleanup. */ }
  targetContext = null;
  targetPage = null;
  historyDepth = 0;
  historyForwardDepth = 0;
  updateRuntime({
    phase: bridge ? 'paired' : 'idle',
    sessionActive: false,
    currentUrl: '',
    title: '',
    frameRate: 0,
  });
  endRelaySession();
  sendBridgeJson({ type: 'session-stopped', reason });
}

function noteActivity(kind = 'active') {
  const now = Date.now();
  activeUntil = Math.max(activeUntil, now + 1_600);
  if (kind === 'motion') motionUntil = Math.max(motionUntil, now + 800);
}

async function handleTouchCommand(command) {
  if (!targetCdp) return;
  const pointerId = Number(command.pointerId || 1);
  const point = {
    x: Math.max(0, Math.min(VIEWPORT.width, Number(command.x || 0))),
    y: Math.max(0, Math.min(VIEWPORT.height, Number(command.y || 0))),
    id: pointerId,
    radiusX: 2,
    radiusY: 2,
    force: command.action === 'up' ? 0 : 1,
  };
  if (command.action === 'down') activeTouches.set(pointerId, point);
  else if (command.action === 'move') activeTouches.set(pointerId, point);
  else activeTouches.delete(pointerId);
  const type = command.action === 'down'
    ? 'touchStart'
    : (command.action === 'move' ? 'touchMove' : (command.action === 'cancel' ? 'touchCancel' : 'touchEnd'));
  await targetCdp.send('Input.dispatchTouchEvent', {
    type,
    touchPoints: [...activeTouches.values()],
  });
}

async function handleCommand(command) {
  if (!runtime.sessionActive || !targetPage || !command) return;
  if (command.type === 'navigate') {
    const url = normalizedNavigationUrl(command.url);
    updateRuntime({ phase: 'loading' });
    sendState();
    noteActivity('motion');
    await targetPage.goto(url, { waitUntil: 'domcontentloaded', timeout: 35_000 });
    historyDepth += 1;
    historyForwardDepth = 0;
    await refreshPageState();
    return;
  }
  if (command.type === 'history') {
    noteActivity('motion');
    if (command.action === 'back') {
      const result = await targetPage.goBack({ waitUntil: 'domcontentloaded', timeout: 20_000 }).catch(() => null);
      if (result || historyDepth > 0) {
        historyDepth = Math.max(0, historyDepth - 1);
        historyForwardDepth += 1;
      }
    } else if (command.action === 'forward') {
      const result = await targetPage.goForward({ waitUntil: 'domcontentloaded', timeout: 20_000 }).catch(() => null);
      if (result || historyForwardDepth > 0) {
        historyForwardDepth = Math.max(0, historyForwardDepth - 1);
        historyDepth += 1;
      }
    } else if (command.action === 'reload') {
      await targetPage.reload({ waitUntil: 'domcontentloaded', timeout: 20_000 }).catch(() => null);
    }
    await refreshPageState();
    return;
  }
  if (command.type === 'pointer') {
    noteActivity(command.action === 'move' ? 'motion' : 'active');
    if (command.pointerType === 'touch') {
      await handleTouchCommand(command);
      return;
    }
    const x = Math.max(0, Math.min(VIEWPORT.width, Number(command.x || 0)));
    const y = Math.max(0, Math.min(VIEWPORT.height, Number(command.y || 0)));
    const buttons = ['left', 'middle', 'right'];
    const button = buttons[Math.max(0, Math.min(2, Number(command.button || 0)))] || 'left';
    await targetPage.mouse.move(x, y);
    if (command.action === 'down') await targetPage.mouse.down({ button });
    else if (command.action === 'up' || command.action === 'cancel') await targetPage.mouse.up({ button }).catch(() => undefined);
    return;
  }
  if (command.type === 'wheel') {
    noteActivity('motion');
    await targetPage.mouse.move(Number(command.x || 0), Number(command.y || 0));
    await targetPage.mouse.wheel(Number(command.deltaX || 0), Number(command.deltaY || 0));
    return;
  }
  if (command.type === 'text') {
    noteActivity('active');
    await targetPage.keyboard.insertText(String(command.text || '').slice(0, 2_000));
    return;
  }
  if (command.type === 'key') {
    const allowed = new Set(['Enter', 'Backspace', 'Delete', 'Tab', 'Escape', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight']);
    if (!allowed.has(command.key)) return;
    noteActivity('active');
    await targetPage.keyboard.press(command.key);
  }
}

async function handleBridgeMessage(raw) {
  let payload = null;
  try { payload = JSON.parse(String(raw || '')); } catch { return; }
  if (payload?.type === 'agent-ready') {
    updateRuntime({ agentConnected: true, phase: 'paired', message: 'Mac подключён к аккаунту' });
    sendBridgeJson({
      type: 'agent-credentials',
      agentToken: agentIdentity?.agentToken ?? '',
      pairingCode: agentIdentity?.pairingCode ?? '',
      deviceName: DEVICE_NAME,
    });
    bridgeWaiter?.resolve();
    return;
  }
  if (payload?.type === 'account-status') {
    const paired = Boolean(payload.paired);
    updateRuntime({
      accountPaired: paired,
      phase: paired ? 'paired' : 'awaiting-pair',
      message: paired
        ? 'Mac привязан к аккаунту и готов для всех досок'
        : 'Введите код на главной странице Alex Board',
    });
    return;
  }
  if (payload?.type === 'agent-revoke-result') {
    const waiter = revokeWaiters.get(String(payload.requestId ?? ''));
    if (!waiter) return;
    if (payload.ok) waiter.resolve(Boolean(payload.revoked));
    else waiter.reject(new Error(String(payload.error || 'Не удалось отвязать Mac')));
    return;
  }
  if (payload?.type === 'signal-transport') {
    const transport = ['ably', 'supabase'].includes(payload.transport) ? payload.transport : '';
    updateRuntime({ signalTransport: transport });
    return;
  }
  if (payload?.type === 'start-session') {
    await createTargetSession(payload.sessionId);
    return;
  }
  if (payload?.type === 'stop-session') {
    await closeTargetSession(payload.reason || 'stopped');
    return;
  }
  if (payload?.type === 'command') {
    try {
      await handleCommand(payload.command);
    } catch (error) {
      updateRuntime({ message: error.message });
      sendBridgeJson({ type: 'state', state: { ...safeState(), error: error.message } });
    }
    return;
  }
  if (payload?.type === 'relay-state') {
    const state = payload.state && typeof payload.state === 'object' ? payload.state : null;
    if (!state) return;
    relayState = state;
    broadcastRelayJson({ type: 'remote-state', state });
  }
}

async function stopAgent(reason = 'stopped') {
  stoppingAgent = true;
  try {
    await closeTargetSession(reason);
    bridgeWaiter?.reject(new Error('Mac-сервис остановлен'));
    bridgeWaiter = null;
    revokeWaiters.forEach((waiter) => waiter.reject(new Error('Mac-сервис остановлен')));
    revokeWaiters.clear();
    try { bridge?.close(); } catch { /* Best effort. */ }
    bridge = null;
    try { await agentContext?.close(); } catch { /* Best effort. */ }
    agentContext = null;
    agentPage = null;
    try { await browser?.close(); } catch { /* Best effort. */ }
    browser = null;
    bridgeToken = '';
    boardOrigin = '';
    updateRuntime({
      phase: 'idle',
      message: 'Mac-сервер готов',
      boardUrl: '',
      agentConnected: false,
      accountPaired: false,
      sessionActive: false,
      startedAt: null,
    });
  } finally {
    stoppingAgent = false;
  }
}

async function startAgent() {
  await stopAgent('restarted');
  // A manual reconnect must restore both the hidden account agent and the
  // public fallback tunnel. Coalesce concurrent startup calls so one click can
  // never create two cloudflared processes.
  await ensurePublicRelayTunnel();
  const appUrl = new URL(BOARD_APP_URL);
  if (appUrl.protocol !== 'https:') throw new Error('ALEX_BOARD_APP_URL должен использовать HTTPS.');
  boardOrigin = appUrl.origin;
  agentIdentity = await loadOrCreateAgentIdentity();
  const executablePath = await findChrome();
  bridgeToken = randomBytes(32).toString('base64url');
  updateRuntime({
    phase: 'starting',
    message: 'Запускаю служебный Chrome…',
    boardUrl: appUrl.origin + appUrl.pathname,
    pairingCode: agentIdentity.pairingCode,
    startedAt: Date.now(),
  });
  browser = await chromium.launch({
    executablePath,
    headless: true,
    args: [
      '--no-first-run',
      '--disable-background-timer-throttling',
      '--disable-renderer-backgrounding',
      '--disable-backgrounding-occluded-windows',
      '--autoplay-policy=no-user-gesture-required',
      // The agent page is HTTPS, while its authenticated one-time bridge lives on
      // loopback. Current Chrome blocks that local bridge unless LNA is disabled
      // for this isolated, headless process. The service still binds to 127.0.0.1
      // and validates the random bridge token on every WebSocket upgrade.
      '--disable-features=LocalNetworkAccessChecks,PrivateNetworkAccessChecks,PrivateNetworkAccessRespectPreflightResults,BlockInsecurePrivateNetworkRequests',
    ],
  });
  browser.on('disconnected', () => {
    browser = null;
    agentContext = null;
    agentPage = null;
    if (stoppingAgent) return;
    try { bridge?.close(); } catch { /* Best effort. */ }
    bridge = null;
    updateRuntime({
      phase: 'error',
      message: 'Служебный Chrome закрылся. Нажмите «Подключить Mac» ещё раз.',
      agentConnected: false,
      sessionActive: false,
    });
  });
  agentContext = await browser.newContext({ viewport: VIEWPORT });
  // The production board already falls back to Supabase when the optional Ably
  // token function is unavailable. Keep the currently deployed 1.33.0 Mac
  // agent on that same fallback; board 1.33.2 also performs this automatically.
  await agentContext.route('https://cdn.ably.com/**', (route) => route.abort('blockedbyclient'));
  await agentContext.addInitScript(() => {
    localStorage.setItem('alex-board:owner-name', 'Браузер на Mac');
  });
  agentPage = await agentContext.newPage();
  const bridgePromise = waitForBridge();
  await agentPage.goto(agentUrlForAccount(), {
    waitUntil: 'domcontentloaded',
    timeout: 35_000,
  });
  await bridgePromise;
  updateRuntime({ phase: 'paired', message: 'Mac подключён к аккаунту', agentConnected: true });
}

const CONTENT_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
};

const server = createServer(async (request, response) => {
  const url = new URL(request.url || '/', `http://${HOST}:${PORT}`);
  const requestHost = String(request.headers.host || '').toLowerCase();
  const localDashboardHost = requestHost === `${HOST}:${PORT}` || requestHost === `localhost:${PORT}`;
  if (!localDashboardHost) {
    response.writeHead(404, {
      'content-type': 'text/plain; charset=utf-8',
      'cache-control': 'no-store',
      'x-content-type-options': 'nosniff',
    }).end('Not found');
    return;
  }
  if (request.method === 'GET' && url.pathname === '/api/status') {
    jsonResponse(response, 200, runtime);
    return;
  }
  if (request.method === 'POST' && url.pathname === '/api/start') {
    if (!dashboardRequestAuthorized(request)) {
      jsonResponse(response, 403, { error: 'Недействительный локальный запрос' });
      return;
    }
    try {
      await readJsonBody(request).catch(() => ({}));
      await startAgent();
      jsonResponse(response, 200, runtime);
    } catch (error) {
      updateRuntime({ phase: 'error', message: error.message });
      jsonResponse(response, 400, { error: error.message });
    }
    return;
  }
  if (request.method === 'POST' && url.pathname === '/api/stop') {
    if (!dashboardRequestAuthorized(request)) {
      jsonResponse(response, 403, { error: 'Недействительный локальный запрос' });
      return;
    }
    await stopAgent('dashboard-stopped');
    jsonResponse(response, 200, runtime);
    return;
  }
  if (request.method === 'POST' && url.pathname === '/api/revoke-self') {
    if (!dashboardRequestAuthorized(request)) {
      jsonResponse(response, 403, { error: 'Недействительный локальный запрос' });
      return;
    }
    try {
      await readJsonBody(request).catch(() => ({}));
      await requestAgentRevocation();
      jsonResponse(response, 200, { revoked: true });
    } catch (error) {
      jsonResponse(response, 409, { error: error.message });
    }
    return;
  }
  if (request.method === 'POST' && url.pathname === '/api/shutdown') {
    if (!dashboardRequestAuthorized(request)) {
      jsonResponse(response, 403, { error: 'Недействительный локальный запрос' });
      return;
    }
    await readJsonBody(request).catch(() => ({}));
    jsonResponse(response, 200, { stopping: true });
    setTimeout(() => shutdown(), 120).unref();
    return;
  }

  const fileName = url.pathname === '/' ? 'index.html' : url.pathname.slice(1);
  if (!['index.html', 'app.js', 'styles.css'].includes(fileName)) {
    response.writeHead(404).end('Not found');
    return;
  }
  const filePath = join(PUBLIC_DIR, fileName);
  if (fileName === 'index.html') {
    const template = await readFile(filePath, 'utf8');
    const body = template.replace('__ALEX_DASHBOARD_TOKEN_VALUE__', DASHBOARD_TOKEN);
    response.writeHead(200, {
      'content-type': CONTENT_TYPES['.html'],
      'content-length': Buffer.byteLength(body),
      'cache-control': 'no-store',
      'content-security-policy': "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self'; connect-src 'self'",
      'x-frame-options': 'DENY',
    });
    response.end(body);
    return;
  }
  response.writeHead(200, {
    'content-type': CONTENT_TYPES[extname(filePath)] || 'application/octet-stream',
    'cache-control': 'no-store',
    'x-content-type-options': 'nosniff',
  });
  createReadStream(filePath).pipe(response);
});

server.on('error', (error) => {
  if (error?.code === 'EADDRINUSE') {
    process.stderr.write(`Alex Browser Server уже работает: http://${HOST}:${PORT}\n`);
    process.exitCode = 0;
    return;
  }
  process.stderr.write(`Alex Browser Server: ${error?.message || error}\n`);
  process.exitCode = 1;
});

const webSocketServer = new WebSocketServer({ noServer: true, maxPayload: 64 * 1024 });
const relayWebSocketServer = new WebSocketServer({ noServer: true, maxPayload: 24 * 1024 });
server.on('upgrade', (request, socket, head) => {
  const url = new URL(request.url || '/', `http://${HOST}:${PORT}`);
  const remoteAddress = String(request.socket.remoteAddress || '');
  const localClient = remoteAddress === '127.0.0.1' || remoteAddress === '::1' || remoteAddress === '::ffff:127.0.0.1';

  if (url.pathname === '/relay') {
    const viewerId = String(url.searchParams.get('viewer') || '').slice(0, 120);
    const allowed = relayRequestIsAllowed({
      origin: request.headers.origin,
      boardOrigin,
      sessionId: url.searchParams.get('session'),
      expectedSessionId: relaySessionId,
      token: url.searchParams.get('token'),
      expectedToken: relaySessionToken,
      viewerId,
    });
    if (!allowed) {
      socket.destroy();
      return;
    }
    const existing = relayClients.get(viewerId);
    if (!existing && relayClients.size >= MAX_RELAY_VIEWERS) {
      socket.destroy();
      return;
    }
    relayWebSocketServer.handleUpgrade(request, socket, head, (webSocket) => {
      if (existing && existing !== webSocket) {
        try { existing.close(1000, 'reconnected'); } catch { /* Best effort. */ }
      }
      relayClients.set(viewerId, webSocket);
      updateRuntime({ relayViewers: relayClients.size });
      try {
        webSocket.send(JSON.stringify({ type: 'relay-ready' }));
        if (relayState) webSocket.send(JSON.stringify({ type: 'remote-state', state: relayState }));
        if (lastDeliveredFrame) webSocket.send(lastDeliveredFrame, { binary: true });
      } catch {
        // A failed initial write is handled by the close event.
      }
      webSocket.on('message', (data, isBinary) => {
        if (isBinary || data.length > 24 * 1024) return;
        let command = null;
        try { command = JSON.parse(data.toString()); } catch { return; }
        if (!['control-request', 'control-release', 'pointer', 'wheel', 'text', 'key', 'navigate', 'history'].includes(command?.type)) return;
        sendBridgeJson({ type: 'relay-command', viewerId, command });
      });
      webSocket.on('close', () => {
        if (relayClients.get(viewerId) !== webSocket) return;
        relayClients.delete(viewerId);
        updateRuntime({ relayViewers: relayClients.size });
      });
    });
    return;
  }

  if (url.pathname !== '/bridge' || url.searchParams.get('token') !== bridgeToken || !localClient) {
    socket.destroy();
    return;
  }
  webSocketServer.handleUpgrade(request, socket, head, (webSocket) => {
    if (bridge && bridge !== webSocket) bridge.close();
    bridge = webSocket;
    bridge.on('message', (data, isBinary) => {
      if (isBinary) return;
      handleBridgeMessage(data.toString()).catch((error) => updateRuntime({ message: error.message }));
    });
    sendRelaySessionInfo();
    bridge.on('close', () => {
      if (bridge === webSocket) {
        bridge = null;
        updateRuntime({ agentConnected: false, phase: browser ? 'starting' : 'idle' });
      }
    });
  });
});

server.listen(PORT, HOST, () => {
  const dashboardUrl = `http://${HOST}:${PORT}`;
  process.stdout.write(`Alex Browser Server: ${dashboardUrl}\n`);
  ensurePublicRelayTunnel().catch((error) => updateRuntime({
    relayPhase: 'error',
    relayMessage: `Резервный канал не запустился: ${error.message}`,
    relayUrl: '',
  }));
  startAgent().catch((error) => updateRuntime({
    phase: 'error',
    message: error.message,
  }));
  if (process.platform === 'darwin' && process.env.ALEX_BROWSER_NO_OPEN !== '1') {
    const opener = spawn('/usr/bin/open', [dashboardUrl], { detached: true, stdio: 'ignore' });
    opener.unref();
  }
});

const idleFrameRateTimer = setInterval(() => {
  if (!runtime.sessionActive || !lastFrameSentAt || Date.now() - lastFrameSentAt <= 1_200) return;
  if (runtime.frameRate !== 0) updateRuntime({ frameRate: 0 });
  sendState();
}, 1_000);
idleFrameRateTimer.unref();

async function shutdown() {
  clearInterval(idleFrameRateTimer);
  const currentTunnel = tunnelProcess;
  tunnelProcess = null;
  if (currentTunnel) {
    try { currentTunnel.kill('SIGTERM'); } catch { /* Best effort. */ }
  }
  await stopAgent('server-closed');
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(0), 2_000).unref();
}

process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
