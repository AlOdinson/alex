export function validateBoardUrl(value) {
  const url = new URL(String(value || '').trim());
  if (!['https:', 'http:'].includes(url.protocol)) throw new Error('Нужна ссылка http или https');
  if (!/\/board\/[A-Za-z0-9_-]+$/.test(url.pathname)) {
    throw new Error('Это не ссылка на доску Alex Board');
  }
  if (String(url.searchParams.get('key') || '').length < 20) {
    throw new Error('В ссылке отсутствует учительский ключ');
  }
  return url;
}

export function privateHostname(hostname) {
  const host = String(hostname || '').toLowerCase().replace(/^\[|\]$/g, '');
  if (host === 'localhost' || host.endsWith('.local') || host === '::1') return true;
  if (/^127\./.test(host) || /^10\./.test(host) || /^192\.168\./.test(host)) return true;
  const match = host.match(/^172\.(\d{1,3})\./);
  if (match && Number(match[1]) >= 16 && Number(match[1]) <= 31) return true;
  const isIpv6 = host.includes(':');
  return /^169\.254\./.test(host)
    || (isIpv6 && /^(?:fe80:|fc|fd)/i.test(host));
}

export function normalizedNavigationUrl(value) {
  const input = String(value || '').trim();
  if (!input) throw new Error('Введите адрес сайта');
  if (/\s/.test(input) && !/^https?:\/\//i.test(input)) {
    return `https://duckduckgo.com/?q=${encodeURIComponent(input)}`;
  }
  const candidate = /^[A-Za-z][A-Za-z\d+.-]*:/.test(input) ? input : `https://${input}`;
  const url = new URL(candidate);
  if (!['http:', 'https:'].includes(url.protocol)) throw new Error('Разрешены только сайты http и https');
  if (privateHostname(url.hostname)) throw new Error('Локальные адреса Mac недоступны участникам доски');
  url.username = '';
  url.password = '';
  return url.toString();
}

export function remoteRequestIsAllowed(value) {
  let url;
  try {
    url = new URL(String(value || ''));
  } catch {
    return false;
  }
  if (['data:', 'blob:', 'about:'].includes(url.protocol)) return true;
  if (!['http:', 'https:', 'ws:', 'wss:'].includes(url.protocol)) return false;
  return !privateHostname(url.hostname);
}
