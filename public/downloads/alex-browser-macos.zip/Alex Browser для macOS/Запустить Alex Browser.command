#!/bin/zsh
set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PAYLOAD_DIR="$SCRIPT_DIR/.alex-browser"
if [ ! -f "$PAYLOAD_DIR/package.json" ]; then PAYLOAD_DIR="$SCRIPT_DIR"; fi

SERVER_PORT="4318"
SERVICE_LABEL="io.alexboard.browser-server"
SERVICE_DOMAIN="gui/$(id -u)"
SUPPORT_ROOT="$HOME/Library/Application Support/Alex Board"
INSTALL_DIR="$SUPPORT_ROOT/Browser Server"
LAUNCH_AGENTS_DIR="$HOME/Library/LaunchAgents"
PLIST_PATH="$LAUNCH_AGENTS_DIR/$SERVICE_LABEL.plist"
LOG_DIR="$HOME/Library/Logs/Alex Board"
VERSION_MARKER="$INSTALL_DIR/.installed-version"

show_error() {
  echo "$1"
  /usr/bin/osascript -e "display alert \"Alex Browser\" message \"$1\" as critical" >/dev/null 2>&1 || true
}

if [ ! -f "$PAYLOAD_DIR/package.json" ] || [ ! -f "$PAYLOAD_DIR/src/server.mjs" ]; then
  show_error "Повреждён пакет Alex Browser. Скачайте его из аккаунта ещё раз."
  exit 1
fi

if ! command -v node >/dev/null 2>&1; then
  if command -v brew >/dev/null 2>&1; then
    echo "Первый запуск: устанавливаю Node.js…"
    brew install node
  else
    /usr/bin/open "https://nodejs.org/"
    show_error "Для первого запуска нужен Node.js 22 или новее. Открыта страница установки; после установки снова откройте этот файл."
    exit 1
  fi
fi

NODE_PATH="$(command -v node)"
NODE_MAJOR="$($NODE_PATH -p "process.versions.node.split('.')[0]")"
if [ "$NODE_MAJOR" -lt 22 ]; then
  /usr/bin/open "https://nodejs.org/"
  show_error "Установлена старая версия Node.js. Нужна версия 22 или новее."
  exit 1
fi

if ! command -v cloudflared >/dev/null 2>&1; then
  if command -v brew >/dev/null 2>&1; then
    echo "Первый запуск: устанавливаю защищённый канал для учеников…"
    brew install cloudflared
  else
    /usr/bin/open "https://developers.cloudflare.com/cloudflare-one/connections/connect-networks/downloads/"
    show_error "Нужен Cloudflared. Открыта страница установки; после установки снова откройте этот файл."
    exit 1
  fi
fi

SERVER_VERSION="$(PACKAGE_JSON="$PAYLOAD_DIR/package.json" "$NODE_PATH" -p 'require(process.env.PACKAGE_JSON).version')"
EXISTING_PID="$(/usr/sbin/lsof -nP -tiTCP:"$SERVER_PORT" -sTCP:LISTEN | head -n 1)"
if [ -n "$EXISTING_PID" ]; then
  EXISTING_STATUS="$(/usr/bin/curl -fsS --max-time 2 "http://127.0.0.1:$SERVER_PORT/api/status" 2>/dev/null || true)"
  if printf '%s' "$EXISTING_STATUS" | /usr/bin/grep -Fq "\"serverVersion\":\"$SERVER_VERSION\"" \
    && printf '%s' "$EXISTING_STATUS" | /usr/bin/grep -Fq '"backgroundService":true'; then
    /usr/bin/open "http://127.0.0.1:$SERVER_PORT"
    exit 0
  fi

  EXISTING_COMMAND="$(ps -p "$EXISTING_PID" -o args= 2>/dev/null || true)"
  EXISTING_CWD="$(/usr/sbin/lsof -a -p "$EXISTING_PID" -d cwd -Fn 2>/dev/null | /usr/bin/sed -n 's/^n//p')"
  if [[ "$EXISTING_COMMAND" == *"node src/server.mjs"* || "$EXISTING_COMMAND" == *"server.mjs"* ]] \
    && [[ "$EXISTING_CWD" == *"mac-browser-server"* || "$EXISTING_CWD" == "$INSTALL_DIR" ]]; then
    echo "Перевожу предыдущую версию в фоновый режим…"
    kill "$EXISTING_PID" 2>/dev/null || true
    for ATTEMPT in {1..40}; do
      if ! kill -0 "$EXISTING_PID" 2>/dev/null; then break; fi
      sleep 0.1
    done
  else
    show_error "Порт $SERVER_PORT занят другой программой. Закройте её и повторите запуск."
    exit 1
  fi
fi

/bin/launchctl bootout "$SERVICE_DOMAIN/$SERVICE_LABEL" >/dev/null 2>&1 || true
/bin/mkdir -p "$INSTALL_DIR" "$LAUNCH_AGENTS_DIR" "$LOG_DIR"
/usr/bin/rsync -a --exclude node_modules --exclude '.installed-version' "$PAYLOAD_DIR/" "$INSTALL_DIR/"

INSTALLED_VERSION="$(/bin/cat "$VERSION_MARKER" 2>/dev/null || true)"
if [ "$INSTALLED_VERSION" != "$SERVER_VERSION" ] \
  || [ ! -d "$INSTALL_DIR/node_modules/playwright-core" ] \
  || [ ! -d "$INSTALL_DIR/node_modules/ws" ]; then
  echo "Устанавливаю компоненты фонового сервера…"
  (cd "$INSTALL_DIR" && "$NODE_PATH" "$(dirname "$NODE_PATH")/npm" ci --omit=dev --no-audit --no-fund)
  printf '%s' "$SERVER_VERSION" > "$VERSION_MARKER"
fi

PLIST_JSON="$(/usr/bin/mktemp -t alex-browser-plist)"
PLIST_JSON="$PLIST_JSON" \
NODE_PATH="$NODE_PATH" \
INSTALL_DIR="$INSTALL_DIR" \
LOG_DIR="$LOG_DIR" \
SERVICE_LABEL="$SERVICE_LABEL" \
"$NODE_PATH" -e '
  const fs = require("node:fs");
  const path = require("node:path");
  const envPath = [path.dirname(process.env.NODE_PATH), "/opt/homebrew/bin", "/usr/local/bin", "/usr/bin", "/bin", "/usr/sbin", "/sbin"].join(":");
  fs.writeFileSync(process.env.PLIST_JSON, JSON.stringify({
    Label: process.env.SERVICE_LABEL,
    ProgramArguments: [process.env.NODE_PATH, path.join(process.env.INSTALL_DIR, "src/server.mjs")],
    WorkingDirectory: process.env.INSTALL_DIR,
    RunAtLoad: true,
    KeepAlive: { SuccessfulExit: false },
    ThrottleInterval: 5,
    EnvironmentVariables: {
      ALEX_BROWSER_NO_OPEN: "1",
      ALEX_BROWSER_BACKGROUND: "1",
      PATH: envPath,
    },
    StandardOutPath: path.join(process.env.LOG_DIR, "browser-server.log"),
    StandardErrorPath: path.join(process.env.LOG_DIR, "browser-server-error.log"),
  }));
'
/usr/bin/plutil -convert xml1 -o "$PLIST_PATH" "$PLIST_JSON"
/bin/rm -f "$PLIST_JSON"

/bin/launchctl bootstrap "$SERVICE_DOMAIN" "$PLIST_PATH"
/bin/launchctl enable "$SERVICE_DOMAIN/$SERVICE_LABEL" >/dev/null 2>&1 || true
/bin/launchctl kickstart -k "$SERVICE_DOMAIN/$SERVICE_LABEL"

for ATTEMPT in {1..120}; do
  if /usr/bin/curl -fsS --max-time 1 "http://127.0.0.1:$SERVER_PORT/api/status" >/dev/null 2>&1; then
    /usr/bin/open "http://127.0.0.1:$SERVER_PORT"
    exit 0
  fi
  sleep 0.1
done

show_error "Фоновый сервер не ответил. Откройте файл ещё раз; если ошибка повторится, скачайте пакет заново."
exit 1
