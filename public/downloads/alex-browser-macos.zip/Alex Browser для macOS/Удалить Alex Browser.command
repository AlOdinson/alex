#!/bin/zsh
set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SERVER_PORT="4318"
SERVICE_LABEL="io.alexboard.browser-server"
SERVICE_DOMAIN="gui/$(id -u)"
SUPPORT_ROOT="$HOME/Library/Application Support/Alex Board"
INSTALL_DIR="$SUPPORT_ROOT/Browser Server"
AGENT_STATE_FILE="$SUPPORT_ROOT/mac-agent.json"
PLIST_PATH="$HOME/Library/LaunchAgents/$SERVICE_LABEL.plist"
LOG_DIR="$HOME/Library/Logs/Alex Board"

echo "Останавливаю и отвязываю Alex Browser…"

if /usr/bin/curl -fsS --max-time 2 "http://127.0.0.1:$SERVER_PORT/api/status" >/dev/null 2>&1; then
  DASHBOARD_HTML="$(/usr/bin/curl -fsS --max-time 2 "http://127.0.0.1:$SERVER_PORT/" 2>/dev/null || true)"
  DASHBOARD_TOKEN="$(printf '%s' "$DASHBOARD_HTML" | /usr/bin/sed -n "s/.*window\.__ALEX_DASHBOARD_TOKEN__ = '\([^']*\)'.*/\1/p" | head -n 1)"
  if [ -n "$DASHBOARD_TOKEN" ]; then
    /usr/bin/curl -fsS --max-time 10 -X POST "http://127.0.0.1:$SERVER_PORT/api/revoke-self" \
      -H 'Content-Type: application/json' \
      -H 'Origin: http://127.0.0.1:4318' \
      -H "X-Alex-Dashboard-Token: $DASHBOARD_TOKEN" \
      --data '{}' >/dev/null 2>&1 || true
  fi
fi

/bin/launchctl bootout "$SERVICE_DOMAIN/$SERVICE_LABEL" >/dev/null 2>&1 || true
EXISTING_PID="$(/usr/sbin/lsof -nP -tiTCP:"$SERVER_PORT" -sTCP:LISTEN | head -n 1)"
if [ -n "$EXISTING_PID" ]; then
  EXISTING_COMMAND="$(ps -p "$EXISTING_PID" -o args= 2>/dev/null || true)"
  EXISTING_CWD="$(/usr/sbin/lsof -a -p "$EXISTING_PID" -d cwd -Fn 2>/dev/null | /usr/bin/sed -n 's/^n//p')"
  if [[ "$EXISTING_COMMAND" == *"server.mjs"* ]] \
    && [[ "$EXISTING_CWD" == *"mac-browser-server"* || "$EXISTING_CWD" == "$INSTALL_DIR" ]]; then
    kill "$EXISTING_PID" 2>/dev/null || true
  fi
fi

/bin/rm -f "$PLIST_PATH" "$AGENT_STATE_FILE"
if [ -d "$INSTALL_DIR" ]; then /bin/rm -rf "$INSTALL_DIR"; fi
/bin/rm -f "$LOG_DIR/browser-server.log" "$LOG_DIR/browser-server-error.log"

/usr/bin/osascript -e 'display dialog "Alex Browser остановлен, отвязан и удалён с этого Mac." buttons {"Готово"} default button "Готово"' >/dev/null 2>&1 || true

# The downloaded package removes itself only when its hidden payload and both
# control files are present. Moving to Trash keeps this operation recoverable.
if [ -d "$SCRIPT_DIR/.alex-browser" ] \
  && [ -f "$SCRIPT_DIR/Запустить Alex Browser.command" ] \
  && [ -f "$SCRIPT_DIR/Удалить Alex Browser.command" ]; then
  TRASH_TARGET="$HOME/.Trash/Alex Browser для Mac-$(date +%Y%m%d-%H%M%S)"
  /usr/bin/nohup /bin/zsh -c 'sleep 2; /bin/mv "$1" "$2"' -- "$SCRIPT_DIR" "$TRASH_TARGET" >/dev/null 2>&1 &
fi

exit 0
